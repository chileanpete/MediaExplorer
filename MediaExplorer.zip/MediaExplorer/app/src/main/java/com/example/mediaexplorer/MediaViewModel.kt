package com.example.mediaexplorer

import androidx.lifecycle.ViewModel
import com.example.mediaexplorer.datos.Category
import com.example.mediaexplorer.datos.MediaContent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

class MediaViewModel : ViewModel() {
    private val _categories = MutableStateFlow<List<Category>>(emptyList())
    val categories: StateFlow<List<Category>> = _categories

    private var nextCategoryId = 1
    private var nextContentId = 1

    fun addCategory(name: String, description: String) {
        val newCategory = Category(
            idcat = nextCategoryId++,
            name = name,
            description = description,
            contents = emptyList()
        )
        _categories.update { currentList -> currentList + newCategory }
    }

    fun addContent(categoryId: Int, content: MediaContent) {
        _categories.update { currentList ->
            currentList.map { category ->
                if (category.idcat == categoryId) {
                    category.copy(contents = category.contents + content.copy(idcont = nextContentId++))
                } else {
                    category
                }
            }
        }
    }

    fun getCategoryById(id: Int): Category? {
        return _categories.value.find { it.idcat == id }
    }

    fun getContentById(categoryId: Int, contentId: Int): MediaContent? {
        return _categories.value.find { it.idcat == categoryId }
            ?.contents?.find { it.idcont == contentId }
    }
}